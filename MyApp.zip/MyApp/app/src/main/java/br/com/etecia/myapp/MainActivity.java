package br.com.etecia.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    MenuItem pageum, pagedois, pagetres,pagequatro;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        BottomNavigationView bottomNavigationView =
    }

    private void DefinicaoID(){
        pageum = findViewById(R.id.page_1);
        pagedois = findViewById(R.id.page_2);
        pagetres = findViewById(R.id.page_3);
        pagequatro = findViewById(R.id.page_4);

    }
}